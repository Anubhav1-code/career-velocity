import os
import PyPDF2
import docx
import tempfile
from typing import Optional

def extract_text_from_pdf(file_path: str) -> str:
    """Extract text from PDF file"""
    try:
        text = ""
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            
            for page_num in range(len(pdf_reader.pages)):
                page = pdf_reader.pages[page_num]
                text += page.extract_text() + "\n"
        
        return text.strip()
    
    except Exception as e:
        print(f"Error extracting text from PDF {file_path}: {e}")
        return ""

def extract_text_from_docx(file_path: str) -> str:
   
    try:
        doc = docx.Document(file_path)
        text = ""
        
        for paragraph in doc.paragraphs:
            text += paragraph.text + "\n"
        
         
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    text += cell.text + " "
                text += "\n"
        
        return text.strip()
    
    except Exception as e:
        print(f"Error extracting text from DOCX {file_path}: {e}")
        return ""

def extract_text_from_txt(file_path: str) -> str:
    
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            return file.read().strip()
    except UnicodeDecodeError:
        try:
            with open(file_path, 'r', encoding='latin-1') as file:
                return file.read().strip()
        except Exception as e:
            print(f"Error extracting text from TXT {file_path}: {e}")
            return ""
    except Exception as e:
        print(f"Error extracting text from TXT {file_path}: {e}")
        return ""

def extract_text_from_doc(file_path: str) -> str:
    """Extract text from DOC file (legacy Word format)"""
    try:
        return "DOC file format not fully supported. Please convert to DOCX format."
    except Exception as e:
        print(f"Error extracting text from DOC {file_path}: {e}")
        return ""

def extract_text_from_file(file_path: str) -> Optional[str]:

    if not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        return None
    
    _, ext = os.path.splitext(file_path.lower())
    
    if ext == '.pdf':
        return extract_text_from_pdf(file_path)
    elif ext == '.docx':
        return extract_text_from_docx(file_path)
    elif ext == '.txt':
        return extract_text_from_txt(file_path)
    elif ext == '.doc':
        return extract_text_from_doc(file_path)
    else:
        print(f"Unsupported file format: {ext}")
        return None

def extract_text_from_bytes(file_bytes: bytes, filename: str) -> Optional[str]:

    try:
        _, ext = os.path.splitext(filename.lower())
        
        with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as temp_file:
            temp_file.write(file_bytes)
            temp_file_path = temp_file.name
        
        text = extract_text_from_file(temp_file_path)
        
        os.unlink(temp_file_path)
        
        return text
    
    except Exception as e:
        print(f"Error extracting text from bytes for {filename}: {e}")
        return None

def clean_extracted_text(text: str) -> str:

    if not text:
        return ""
    
    lines = text.split('\n')
    cleaned_lines = []
    
    for line in lines:
        line = line.strip()
        if line:  
            cleaned_lines.append(line)
    
    return '\n'.join(cleaned_lines)