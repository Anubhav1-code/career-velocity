import os
import openai
import json
from typing import Dict, Any
from dotenv import load_dotenv

load_dotenv()

class SimpleResumeAnalyzer:
    
    def __init__(self):
        self.api_key = os.getenv('OPENAI_API_KEY')
        if not self.api_key:
            print("Warning: OpenAI API key not found. Using rule-based analysis.")
            self.use_ai = False
        else:
            self.client = openai.OpenAI(api_key=self.api_key)
            self.use_ai = True
    
    def analyze_resume(self, resume_text: str) -> Dict[str, Any]:

        if self.use_ai:
            try:
                return self._ai_analysis(resume_text)
            except Exception as e:
                print(f"AI analysis failed: {e}")
                return self._rule_based_analysis(resume_text)
        else:
            return self._rule_based_analysis(resume_text)
    
    def _ai_analysis(self, resume_text: str) -> Dict[str, Any]:
       
        
        prompt = f"""
Analyze this resume and provide a professional assessment:

RESUME TEXT:
{resume_text}

Please analyze this resume as a professional HR expert and provide:

1. Overall Quality Score (0-100): How professional and effective is this resume?
2. Specific Improvement Suggestions (5-8 points): What can be improved?

Consider these factors:
- Professional formatting and structure
- Clarity of experience and achievements
- Relevant skills and qualifications  
- Use of quantifiable metrics and results
- Contact information completeness
- Grammar and language quality
- Industry relevance and keywords

Respond in this exact JSON format:
{{
    "match_percentage": <score 0-100>,
    "improvements": [
        "Specific suggestion 1",
        "Specific suggestion 2", 
        "Specific suggestion 3",
        "Specific suggestion 4",
        "Specific suggestion 5"
    ]
}}

Make sure your response is valid JSON format only.
"""
        
        response = self.client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a professional HR expert and resume analyst. Always respond with valid JSON format only."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=1000,
            temperature=0.3
        )
        
        result_text = response.choices[0].message.content
        return self._parse_response(result_text)
    
    def _rule_based_analysis(self, resume_text: str) -> Dict[str, Any]:
       
        
        resume_lower = resume_text.lower()
        score = 50  
        improvements = []
        
        if any(indicator in resume_lower for indicator in ['email', '@', 'phone', 'contact']):
            score += 15
        else:
            improvements.append("Add clear contact information (email, phone number)")
        
        if any(word in resume_lower for word in ['experience', 'work', 'employment', 'career']):
            score += 15
        else:
            improvements.append("Include a clear work experience section")
        
        if any(word in resume_lower for word in ['skills', 'technical', 'programming', 'software']):
            score += 10
        else:
            improvements.append("Add a skills section highlighting your technical abilities")
        
        if any(word in resume_lower for word in ['education', 'degree', 'university', 'college']):
            score += 10
        else:
            improvements.append("Include education background")
        
        import re
        numbers = re.findall(r'\d+%|\$\d+|\d+\+', resume_text)
        if len(numbers) >= 3:
            score += 15
        elif len(numbers) >= 1:
            score += 8
        else:
            improvements.append("Add quantifiable achievements (percentages, dollar amounts, metrics)")
        
        word_count = len(resume_text.split())
        if 200 <= word_count <= 800:
            score += 10
        elif word_count < 200:
            improvements.append("Resume seems too short - add more details about your experience")
        else:
            improvements.append("Resume might be too long - focus on most relevant information")
        
        if score >= 70:
            improvements.extend([
                "Consider using action verbs to start bullet points",
                "Ensure consistent formatting throughout",
                "Proofread for any grammatical errors"
            ])
        else:
            improvements.extend([
                "Improve overall structure and organization",
                "Add more specific examples of your work",
                "Use professional language throughout"
            ])
        
        return {
            'match_percentage': min(100, max(0, score)),
            'improvements': improvements[:8] 
        }
    
    def _parse_response(self, text: str) -> Dict[str, Any]:
        try:
            start_idx = text.find('{')
            end_idx = text.rfind('}') + 1
            
            if start_idx != -1 and end_idx > start_idx:
                json_str = text[start_idx:end_idx]
                result = json.loads(json_str)
                
                match_percentage = result.get('match_percentage', 0)
                improvements = result.get('improvements', [])
                
                return {
                    'match_percentage': max(0, min(100, int(match_percentage))),
                    'improvements': improvements[:8] if isinstance(improvements, list) else []
                }
        except:
            pass
        
        return self._rule_based_analysis("")

analyzer = SimpleResumeAnalyzer()

def analyze_resume(resume_text: str) -> Dict[str, Any]:

    return analyzer.analyze_resume(resume_text)