import os
import json
from typing import Dict, Any
from dotenv import load_dotenv

# LangChain imports
from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema.output_parser import StrOutputParser

load_dotenv()

def get_job_requirements():
    try:
        current_dir = os.path.dirname(__file__)
        required_file_path = os.path.join(current_dir, 'required.txt')
        
        with open(required_file_path, 'r', encoding='utf-8') as file:
            content = file.read()
        
        lines = content.split('\n')
        job_title = "Data Analyst" 
        
        for line in lines:
            if line.strip().startswith('Job Title:'):
                job_title = line.replace('Job Title:', '').strip()
                break
        
        required_skills = extract_required_skills(content)
        
        return {
            'job_title': job_title,
            'full_requirements': content,
            'required_skills': required_skills
        }
    except Exception as e:
        print(f"Error reading job requirements: {e}")
        return {
            'job_title': "General Position",
            'full_requirements': "No specific job requirements available.",
            'required_skills': []
        }

def extract_required_skills(job_text):
    job_lower = job_text.lower()
    
    technical_skills = [
        'python', 'sql', 'mysql', 'postgresql', 'pandas', 'numpy', 
        'matplotlib', 'seaborn', 'power bi', 'tableau', 'excel',
        'dax', 'power query', 'google analytics', 'seo', 'beautifulsoup',
        'web scraping', 'data visualization', 'dashboard', 'database',
        'business intelligence', 'data analysis'
    ]
    
    education_requirements = [
        'bachelor', 'master', 'degree', 'computer science', 
        'business administration', 'statistics'
    ]
    
    soft_skills = [
        'analytical thinking', 'problem solving', 'communication',
        'project management', 'teamwork'
    ]
    
    found_skills = {
        'technical': [skill for skill in technical_skills if skill in job_lower],
        'education': [skill for skill in education_requirements if skill in job_lower],
        'soft_skills': [skill for skill in soft_skills if skill in job_lower]
    }
    
    return found_skills

class LangChainResumeAnalyzer:
    
    def __init__(self):
        self.api_key = os.getenv('OPENAI_API_KEY')
        if not self.api_key:
            raise ValueError("OpenAI API key not found. Please set OPENAI_API_KEY environment variable.")
        
        self.llm = ChatOpenAI(
            openai_api_key=self.api_key,
            model="gpt-3.5-turbo",
            temperature=0.3,
            max_tokens=1000
        )
        
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", "You are a professional HR expert and resume analyst. Analyze resumes against specific job requirements and provide detailed skill-based feedback. BE STRICT with scoring - missing required skills should significantly reduce the match percentage."),
            ("user", """
Analyze this resume against the specific job requirements with focus on skill matching:

JOB TITLE: {job_title}

REQUIRED TECHNICAL SKILLS: {required_technical_skills}
REQUIRED EDUCATION: {required_education}
REQUIRED SOFT SKILLS: {required_soft_skills}

JOB REQUIREMENTS:
{job_requirements}

CANDIDATE'S RESUME:
{resume_text}

IMPORTANT SCORING GUIDELINES:
- If 3+ critical technical skills are missing: MAX 40% match
- If 1-2 critical technical skills are missing: MAX 65% match  
- Only give 80%+ if most required skills are present
- Never give 100% unless ALL major requirements are met

Please provide a comprehensive skill-based assessment:

1. SKILL MATCH SCORE (0-100):
   - Technical skills match: How many required technical skills are present?
   - Education match: Does education background meet requirements?
   - Experience relevance: How relevant is the experience?
   - Overall job fit based on skills
   - REDUCE SCORE SIGNIFICANTLY for missing critical skills

2. DETAILED SKILL ANALYSIS:
   - Present Skills: Which required skills are clearly mentioned in the resume?
   - Missing Skills: Which required skills are completely missing?
   - Skill Gaps: What skill improvements are needed?

3. SPECIFIC IMPROVEMENT RECOMMENDATIONS:
   - Which missing technical skills should be added/learned?
   - How to better highlight existing relevant skills?
   - What experience or projects should be emphasized?

Respond in this exact JSON format:
{{
    "match_percentage": <score 0-100>,
    "job_title": "{job_title}",
    "present_skills": ["skill1", "skill2", "skill3"],
    "missing_skills": ["missing_skill1", "missing_skill2", "missing_skill3"],
    "improvements": [
        "Add missing technical skill: specific_skill",
        "Highlight experience with: specific_area", 
        "Include projects demonstrating: specific_capability",
        "Improve section on: specific_area",
        "Learn and add: specific_missing_skill"
    ]
}}

Ensure your response is valid JSON only.
""")
        ])
        
        
        self.chain = self.prompt | self.llm | StrOutputParser()
    
    def analyze(self, resume_text: str, job_requirements: Dict[str, str] = None) -> Dict[str, Any]:
        try:
            if job_requirements is None:
                job_requirements = get_job_requirements()
            
            required_skills = job_requirements.get('required_skills', {})
            
            result = self.chain.invoke({
                "resume_text": resume_text,
                "job_title": job_requirements['job_title'],
                "job_requirements": job_requirements['full_requirements'],
                "required_technical_skills": ', '.join(required_skills.get('technical', [])),
                "required_education": ', '.join(required_skills.get('education', [])),
                "required_soft_skills": ', '.join(required_skills.get('soft_skills', []))
            })
            
            parsed_result = self._parse_response(result, job_requirements['job_title'])
            return parsed_result
            
        except Exception as e:
            print(f"LangChain analysis error: {e}")
            return self._fallback_analysis(resume_text, job_requirements)
    
    def _parse_response(self, response_text: str, job_title: str = "General Position") -> Dict[str, Any]:
        try:
            start_idx = response_text.find('{')
            end_idx = response_text.rfind('}') + 1
            
            if start_idx != -1 and end_idx > start_idx:
                json_str = response_text[start_idx:end_idx]
                result = json.loads(json_str)
                
                match_percentage = result.get('match_percentage', 0)
                improvements = result.get('improvements', [])
                result_job_title = result.get('job_title', job_title)
                present_skills = result.get('present_skills', [])
                missing_skills = result.get('missing_skills', [])
                
                return {
                    'match_percentage': max(0, min(100, int(match_percentage))),
                    'job_title': result_job_title,
                    'present_skills': present_skills[:10] if isinstance(present_skills, list) else [],
                    'missing_skills': missing_skills[:10] if isinstance(missing_skills, list) else [],
                    'improvements': improvements[:8] if isinstance(improvements, list) else []
                }
        except Exception as e:
            print(f"JSON parsing error: {e}")
        
        return self._fallback_analysis("", {'job_title': job_title, 'full_requirements': '', 'required_skills': {}})
    
    def _fallback_analysis(self, resume_text: str, job_requirements: Dict[str, str] = None) -> Dict[str, Any]:
        import re
        
        if job_requirements is None:
            job_requirements = get_job_requirements()
        
        resume_lower = resume_text.lower()
        required_skills = job_requirements.get('required_skills', {})
        
        score = 20  
        improvements = []
        present_skills = []
        missing_skills = []
        
        all_required_technical = required_skills.get('technical', [])
        technical_score = 0
        max_technical_score = 50  
        
        if len(all_required_technical) > 0:
            for skill in all_required_technical:
                if skill.lower() in resume_lower:
                    present_skills.append(skill)
                    technical_score += max_technical_score / len(all_required_technical)
                else:
                    missing_skills.append(skill)
                    improvements.append(f"Add missing technical skill: {skill}")
        
        score += technical_score
        
        education_terms = required_skills.get('education', [])
        education_found = any(term.lower() in resume_lower for term in education_terms)
        if education_found:
            score += 15
            present_skills.extend([term for term in education_terms if term.lower() in resume_lower])
        else:
            if education_terms:
                missing_skills.extend(education_terms[:2]) 
                improvements.append("Include relevant educational background")
        
        if len(re.findall(r'\d+%|\$\d+|\d+\+|increased.*\d+|improved.*\d+', resume_text)) >= 2:
            score += 10
        else:
            improvements.append("Add quantifiable achievements and metrics")
        
        if any(word in resume_lower for word in ['project', 'analysis', 'dashboard', 'report']):
            score += 10
        else:
            improvements.append("Include relevant data analysis projects")
        
        if any(indicator in resume_lower for indicator in ['email', '@', 'phone']):
            score += 5
        else:
            improvements.append("Add complete contact information")
        
        critical_missing = len([skill for skill in missing_skills if skill.lower() in ['python', 'sql', 'power bi', 'tableau']])
        if critical_missing > 0:
            score = max(20, score - (critical_missing * 10))  
        
        if len(missing_skills) > len(present_skills):
            score = min(score, 60)  
        
        if len(missing_skills) > 0:
            top_missing = missing_skills[:3]
            for skill in top_missing:
                if f"Add missing technical skill: {skill}" not in improvements:
                    improvements.append(f"Learn and highlight: {skill}")
        
        while len(improvements) < 5:
            generic_improvements = [
                f"Tailor resume specifically for {job_requirements['job_title']} role",
                "Use action verbs to describe achievements", 
                "Include relevant industry keywords",
                "Highlight problem-solving capabilities",
                "Show progression in data analysis skills"
            ]
            for imp in generic_improvements:
                if imp not in improvements:
                    improvements.append(imp)
                    break
        
        final_score = min(95, max(15, int(score)))  
        
        return {
            'match_percentage': final_score,
            'job_title': job_requirements['job_title'],
            'present_skills': present_skills[:10],
            'missing_skills': missing_skills[:10],
            'improvements': improvements[:8]
        }

langchain_analyzer = None

def analyze_resume_with_langchain(resume_text: str) -> Dict[str, Any]:
    """
    Main function to analyze resume using LangChain against job requirements
    """
    global langchain_analyzer
    
    try:
        job_requirements = get_job_requirements()
        
        if langchain_analyzer is None:
            langchain_analyzer = LangChainResumeAnalyzer()
        
        result = langchain_analyzer.analyze(resume_text, job_requirements)
        return result
        
    except Exception as e:
        print(f"Error in LangChain analysis: {e}")
        
        job_requirements = get_job_requirements()
        return {
            'match_percentage': 0,
            'job_title': job_requirements['job_title'],
            'present_skills': [],
            'missing_skills': job_requirements.get('required_skills', {}).get('technical', [])[:5],
            'improvements': [
                'Unable to analyze resume using AI at this time.',
                'Please try again later.',
                'Check your internet connection and try again.',
                f'Consider reviewing your resume manually against {job_requirements["job_title"]} requirements.',
                'Ensure you have the required technical skills mentioned in the job posting.'
            ]
        }