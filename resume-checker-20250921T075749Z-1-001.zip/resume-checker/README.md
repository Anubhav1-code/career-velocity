# 🤖 Resume Analyzer with LangChain + OpenAI

**Simple AI-powered resume analysis system** that analyzes your uploaded resume and provides professional feedback.

## ✨ Features

- **🔤 Text Extraction**: Extract text from PDF, DOCX, DOC, TXT files
- **🤖 AI Analysis**: Professional resume analysis using LangChain + OpenAI  
- **📊 Score Rating**: 0-100% match percentage with detailed feedback
- **💡 Smart Suggestions**: Specific improvement recommendations
- **🚀 Simple Workflow**: Upload → Extract → Analyze → Results

## 🛠️ Technology Stack

- **Backend**: Python Flask
- **AI Framework**: LangChain + OpenAI GPT-3.5
- **File Processing**: PyPDF2, python-docx  
- **Frontend**: HTML5, CSS3, JavaScript

## ⚡ Quick Setup

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure API Key
Create `.env` file:
```env
OPENAI_API_KEY=your_openai_api_key_here
```

### 3. Run Application
```bash
python main.py
```

### 4. Open Browser
```
http://localhost:5000
```

## 🎯 How It Works

```
📄 Upload Resume → 🔤 Extract Text → 🤖 LangChain Analysis → 📊 Results
```

### Analysis Process:
1. **File Upload**: User uploads resume (PDF/DOCX/DOC/TXT)
2. **Text Extraction**: System extracts clean text from file
3. **AI Analysis**: LangChain + OpenAI analyzes resume quality
4. **Smart Scoring**: Returns match percentage (0-100%)
5. **Improvement Tips**: Provides specific suggestions

## 📊 Sample Results

```json
{
    "match_percentage": 78,
    "improvements": [
        "Add quantifiable achievements with specific metrics",
        "Include relevant technical certifications",
        "Improve action verb usage in experience section",
        "Add links to portfolio or GitHub profile",
        "Enhance skills section with industry keywords"
    ]
}
```

## 📁 Project Structure

```
resume-analyzer/
├── main.py                   # Clean Flask application
├── requirements.txt          # Essential dependencies
├── .env                     # API keys (create this)
├── templates/
│   └── index.html          # Upload interface
├── uploads/                # Temporary file storage
└── utils/
    ├── file_processor.py   # Text extraction
    ├── langchain_analyzer.py # LangChain + OpenAI integration
    └── resume_analyzer.py  # Fallback analyzer
```

## 🔧 Configuration

### Required Environment Variables:
```env
OPENAI_API_KEY=sk-...  # Your OpenAI API key
```

### Optional Settings:
- **Model**: gpt-3.5-turbo (default)
- **Temperature**: 0.3 (for consistent results)
- **Max Tokens**: 1000
- **File Size Limit**: 16MB

## 🚀 Usage Examples

### Web Interface:
1. Open `http://localhost:5000`
2. Upload resume file
3. Wait for AI analysis
4. View results with suggestions

### API Endpoint:
```bash
curl -X POST http://localhost:5000/upload \
  -F "resume=@my_resume.pdf"
```

## ⚠️ Troubleshooting

### Common Issues:

1. **OpenAI API Error**: 
   - Check API key in `.env` file
   - Verify billing setup on OpenAI account

2. **File Upload Error**:
   - Ensure file is PDF/DOCX/DOC/TXT format
   - Check file size (max 16MB)

3. **Import Errors**:
   - Run: `pip install -r requirements.txt`
   - Check Python version (3.8+)

### Debug Mode:
```bash
export FLASK_DEBUG=True
python main.py
```

## 🎯 Use Cases

- **Job Seekers**: Improve resume before applications
- **Career Counselors**: Provide data-driven feedback  
- **HR Teams**: Standardize resume evaluation
- **Students**: Learn professional resume standards

## 🔒 Privacy & Security

- ✅ Files processed temporarily and deleted
- ✅ No persistent storage of user data
- ✅ API keys stored securely in environment
- ✅ Local processing for maximum privacy

## 📈 Future Enhancements

- 🔄 Multiple AI model support
- 📊 Advanced analytics dashboard
- 🎨 Resume template suggestions
- 🌐 Multi-language support
- 📱 Mobile-responsive design

## 📄 License

MIT License - You can freely use and modify this project.

---

**Built with ❤️ using LangChain + OpenAI for better career outcomes** 🚀