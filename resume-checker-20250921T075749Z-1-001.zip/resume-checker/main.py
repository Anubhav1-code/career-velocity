
from flask import Flask, request, render_template, jsonify
import os
from werkzeug.utils import secure_filename
from utils.file_processor import extract_text_from_file
from utils.langchain_analyzer import analyze_resume_with_langchain, get_job_requirements

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max

# Allowed file extensions
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'doc', 'docx'}

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    """Home page with upload form"""
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_and_analyze():
    """Handle resume upload and analysis"""
    try:
        # Check if file was uploaded
        if 'resume' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['resume']
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not allowed_file(file.filename):
            return jsonify({'error': 'File type not allowed. Please upload PDF, DOCX, DOC, or TXT files.'}), 400
        
        # Save uploaded file temporarily
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Extract text from uploaded resume
        resume_text = extract_text_from_file(filepath)
        
        if not resume_text or len(resume_text.strip()) < 50:
            os.remove(filepath)
            return jsonify({'error': 'Could not extract sufficient text from file. Please check file format.'}), 400
        
        # Analyze resume using LangChain
        analysis_result = analyze_resume_with_langchain(resume_text)
        
        # Clean up uploaded file
        os.remove(filepath)
        
        return jsonify(analysis_result)
        
    except Exception as e:
        # Clean up file if it exists
        if 'filepath' in locals() and os.path.exists(filepath):
            os.remove(filepath)
        
        return jsonify({'error': f'An error occurred: {str(e)}'}), 500

@app.route('/job-info')
def get_job_info():
    """Get job information endpoint"""
    try:
        job_requirements = get_job_requirements()
        return jsonify({
            'job_title': job_requirements['job_title'],
            'status': 'success'
        })
    except Exception as e:
        return jsonify({
            'job_title': 'General Position',
            'status': 'error',
            'message': str(e)
        })

@app.route('/health')
def health_check():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'service': 'Resume Analyzer'})

if __name__ == '__main__':
    # Create upload directory if it doesn't exist
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    
    # Run the Flask app
    app.run(debug=True, host='0.0.0.0', port=5000)